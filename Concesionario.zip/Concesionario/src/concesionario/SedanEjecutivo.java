/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package concesionario;

/**
 *
 * @author USUARIO
 */
public class SedanEjecutivo {
    private int LongitudDelCarro;
    private String Materiales;
    private double NivelDeInsonorizacion;
    private boolean Electrico;
    
    public void Oficina(){
        System.out.println("oficina Movil");
    }
}
